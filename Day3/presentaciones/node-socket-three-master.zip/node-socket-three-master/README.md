
# Workshop: Node.js + socket.io + three.js
Slides: [http://slides.com/mgmerino/nodejs-socketio-threejs](http://slides.com/mgmerino/nodejs-socketio-threejs)

## Description
Node and socket.io give us the power of having real-time comunications between devices. Three.js is a WebGL-based Javascript Library. We'll mix them up to explore the core concepts on those libraries and show the posibilities it offers.
